#ifndef UTILS_H
#define UTILS_H

#define TRUE = 1;
#define FALSE = 0;

void upper(char str[]);

#endif
